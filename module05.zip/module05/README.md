# Smart Expense Tracker – AI-Powered Mini Project

**Internship:** Data Science / AI – Codomax Digital Solutions
**Module 05:** AI Tools & Mini Project (Day 17 – Day 20)

An upgrade of my Module 02 Expense Tracker. Instead of picking a category by hand, a small machine-learning model reads the description (e.g. *"uber to railway station"*) and suggests the category. The app also flags unusual expenses and forecasts next month's spending.

## AI features
| Feature | Technique | What it does |
|---|---|---|
| Auto-categorisation | TF-IDF (word + character n-grams) + Logistic Regression (scikit-learn) | Suggests a category and shows its confidence; the user can override |
| Safe fallback | Confidence and margin thresholds | If the model is unsure or two categories are nearly tied, it returns "Other" instead of guessing |
| Anomaly detection | Per-category z-score (≥ 2) | Flags expenses far above the usual amount for that category |
| Forecast | Linear trend (`numpy.polyfit`) over monthly totals | Estimates next month's spend (needs 3+ months of data) |

## Run
```
pip install -r requirements.txt
python smart_expense_tracker.py
```
Test: `python -m unittest test_smart_expense_tracker.py -v`
Check the classifier: `python evaluate_classifier.py`

## How well does the classifier work?
On 16 held-out descriptions (`evaluate_classifier.py`) it gets **15/16 (94%)** correct. Please read this number with care:
- The training set is small (about 150 hand-written phrases), and the test set is only 16 phrases.
- After seeing the first evaluation, I added more training vocabulary for the categories it missed. 94% is therefore optimistic and not a clean benchmark.
- It works best on short English descriptions with common words. Brand names or local terms it hasn't seen may fall back to "Other".

Improvement idea: train on a larger real expense dataset, or let the app learn from the user's corrections.

## How I used AI tools
- **Claude (Anthropic)**: helped plan the project, write the first version of the code, and debug it. Testing found a bug (*"biryani with friends"* was labelled Entertainment), which I fixed by adding training examples and a margin check.
- **What I learned**: AI-generated code needs testing. Plausible-looking output can still be wrong, so I checked behaviour with unit tests and held-out examples instead of trusting it.

## Project structure
```
├── smart_expense_tracker.py        # app + ML + insights
├── evaluate_classifier.py          # held-out accuracy check
├── test_smart_expense_tracker.py   # 9 unit tests
├── requirements.txt
└── README.md
```

## Author
Karthik – B.Tech Artificial Intelligence & Data Science
