"""Training data for the expense categoriser.

Short, realistic expense descriptions grouped by category. In a real project
this would be a larger CSV exported from actual spending.
"""

TRAINING_DATA = {
    "Food": [
        "lunch at canteen", "dinner with friends", "swiggy order", "zomato biryani",
        "tea and snacks", "coffee at cafe", "groceries from supermarket", "vegetables and fruits",
        "milk and bread", "pizza", "burger and fries", "breakfast idli dosa",
        "ice cream", "restaurant bill", "chicken biryani", "street food chaat",
        "bakery cake", "juice shop", "mess fees", "dominos order",
    ],
    "Transport": [
        "bus ticket", "auto rickshaw fare", "uber ride", "ola cab", "metro card recharge",
        "petrol for bike", "train ticket", "fuel", "rapido bike taxi", "parking fee",
        "toll charges", "bike service", "monthly bus pass", "flight ticket", "cab to airport",
        "diesel", "railway reservation", "taxi fare", "vehicle repair", "ride to college",
    ],
    "Education": [
        "college fees", "exam fee", "textbook purchase", "notebooks and pens", "online course",
        "udemy course", "coursera subscription", "lab record book", "xerox and printing",
        "project report binding", "library fine", "coding bootcamp", "certification exam",
        "stationery", "workshop registration", "tuition fee", "reference books", "nptel certification",
        "hackathon registration", "study material",
    ],
    "Entertainment": [
        "movie ticket", "netflix subscription", "spotify premium", "gaming recharge", "concert pass",
        "amazon prime video", "youtube premium", "bowling night", "game purchase on steam",
        "cricket match tickets", "theme park entry", "hotstar subscription", "trip with friends",
        "board games", "club entry", "streaming service", "pubg uc top up", "outing at mall",
        "cinema popcorn", "bgmi purchase",
    ],
    "Bills": [
        "electricity bill", "mobile recharge", "wifi bill", "water bill", "gas cylinder",
        "dth recharge", "broadband payment", "rent", "hostel rent", "phone bill postpaid",
        "insurance premium", "emi payment", "credit card bill", "internet recharge", "maintenance charges",
        "airtel recharge", "jio recharge", "loan installment", "property tax", "gas bill",
    ],
    "Other": [
        "gift for friend", "birthday present", "medicine from pharmacy", "doctor consultation",
        "haircut", "clothes shopping", "shoes", "donation", "laundry", "repair of headphones",
        "charger purchase", "salon", "temple offering", "medical test", "spectacles",
        "gym membership", "tailor charges", "wedding contribution", "courier charges", "miscellaneous",
    ],
}


def as_lists():
    """Return (texts, labels) ready for scikit-learn."""
    texts, labels = [], []
    for category, phrases in TRAINING_DATA.items():
        for phrase in phrases:
            texts.append(phrase)
            labels.append(category)
    return texts, labels
