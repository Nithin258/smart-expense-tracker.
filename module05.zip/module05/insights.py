"""Spending insights: anomaly detection and month-end forecast (pure Python)."""
import calendar
from datetime import date, datetime
from statistics import median


def _quartiles(values):
    s = sorted(values)
    n = len(s)
    mid = n // 2
    lower = s[:mid]
    upper = s[mid + (n % 2):]
    return median(lower), median(upper)


def find_unusual_expenses(expenses, min_samples=5, k=1.5):
    """Flag expenses far above the usual amount for their category (IQR rule)."""
    by_cat = {}
    for e in expenses:
        by_cat.setdefault(e["category"], []).append(e)

    flagged = []
    for cat, items in by_cat.items():
        if len(items) < min_samples:
            continue
        q1, q3 = _quartiles([i["amount"] for i in items])
        limit = q3 + k * (q3 - q1)
        for i in items:
            if i["amount"] > limit:
                flagged.append({**i, "limit": round(limit, 2)})
    return sorted(flagged, key=lambda x: x["amount"], reverse=True)


def forecast_month_end(expenses, today=None):
    """Project this month's total spend from the daily average so far."""
    today = today or date.today()
    month_key = today.strftime("%Y-%m")
    spent = sum(e["amount"] for e in expenses if e["date"].startswith(month_key))
    days_elapsed = today.day
    days_in_month = calendar.monthrange(today.year, today.month)[1]
    daily_avg = spent / days_elapsed if days_elapsed else 0.0
    return {
        "spent_so_far": round(spent, 2),
        "daily_average": round(daily_avg, 2),
        "projected_total": round(daily_avg * days_in_month, 2),
        "days_left": days_in_month - days_elapsed,
    }


def top_category(expenses):
    totals = {}
    for e in expenses:
        totals[e["category"]] = totals.get(e["category"], 0) + e["amount"]
    if not totals:
        return None
    cat = max(totals, key=totals.get)
    return cat, round(totals[cat], 2), round(totals[cat] / sum(totals.values()) * 100, 1)


def parse_date(text):
    return datetime.strptime(text, "%Y-%m-%d").date()
