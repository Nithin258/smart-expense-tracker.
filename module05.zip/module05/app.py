"""Smart Expense Tracker - AI-powered upgrade of the Module 02 project.

New in this version:
  * ML auto-categorisation of expenses from their description
  * unusual-spending detection
  * month-end spending forecast
"""
import json
import os
from datetime import date

from categorizer import ExpenseCategorizer
from insights import find_unusual_expenses, forecast_month_end, top_category

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "expenses.json")
CATEGORIES = ["Food", "Transport", "Education", "Entertainment", "Bills", "Other"]


def load_expenses(path=DATA_FILE):
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return []


def save_expenses(expenses, path=DATA_FILE):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(expenses, f, indent=2)


def add_expense(expenses, amount, category, description="", when=None):
    if amount <= 0:
        raise ValueError("Amount must be greater than zero.")
    if category not in CATEGORIES:
        category = "Other"
    next_id = max((e["id"] for e in expenses), default=0) + 1
    expense = {
        "id": next_id,
        "date": when or date.today().isoformat(),
        "amount": round(float(amount), 2),
        "category": category,
        "description": description.strip(),
    }
    expenses.append(expense)
    return expense


def delete_expense(expenses, expense_id):
    for i, e in enumerate(expenses):
        if e["id"] == expense_id:
            return expenses.pop(i)
    return None


def print_expenses(expenses):
    if not expenses:
        print("\nNo expenses recorded yet.")
        return
    print(f"\n{'ID':<4}{'Date':<12}{'Category':<15}{'Amount':>10}  Description")
    print("-" * 62)
    for e in expenses:
        print(f"{e['id']:<4}{e['date']:<12}{e['category']:<15}{e['amount']:>10.2f}  {e['description']}")
    print("-" * 62)
    print(f"{'Total':<31}{sum(e['amount'] for e in expenses):>10.2f}")


def print_insights(expenses):
    if not expenses:
        print("\nAdd some expenses first.")
        return
    print("\n--- AI Insights ---")
    top = top_category(expenses)
    if top:
        print(f"Top category : {top[0]} (Rs. {top[1]:,.2f}, {top[2]}% of spending)")

    f = forecast_month_end(expenses)
    print(f"This month   : Rs. {f['spent_so_far']:,.2f} spent, "
          f"avg Rs. {f['daily_average']:,.2f}/day")
    print(f"Forecast     : about Rs. {f['projected_total']:,.2f} by month end "
          f"({f['days_left']} days left)")

    unusual = find_unusual_expenses(expenses)
    if unusual:
        print("\nUnusually high expenses:")
        for e in unusual[:5]:
            print(f"  #{e['id']} {e['description'] or e['category']}: Rs. {e['amount']:,.2f} "
                  f"(typical limit for {e['category']}: Rs. {e['limit']:,.2f})")
    else:
        print("\nNo unusual expenses detected.")


def read_amount():
    while True:
        try:
            value = float(input("Amount: "))
            if value > 0:
                return value
            print("Amount must be greater than zero.")
        except ValueError:
            print("Please enter a valid number.")


def choose_category(ai, description):
    """Suggest a category with the ML model and let the user accept or override."""
    suggestion, confidence = ai.predict(description)
    print(f"AI suggests: {suggestion} ({confidence:.0%} confident)")
    answer = input("Press Enter to accept, or type a number to change:\n"
                   + "  ".join(f"{i}.{c}" for i, c in enumerate(CATEGORIES, 1)) + "\n> ").strip()
    if answer.isdigit() and 1 <= int(answer) <= len(CATEGORIES):
        return CATEGORIES[int(answer) - 1]
    return suggestion


def main():
    print("Loading AI model...")
    ai = ExpenseCategorizer().train()
    expenses = load_expenses()
    menu = (
        "\n=== Smart Expense Tracker ===\n"
        "1. Add expense (AI categorises it)\n2. View expenses\n3. Delete expense\n"
        "4. AI insights\n5. Model accuracy\n6. Exit"
    )
    while True:
        print(menu)
        choice = input("Select an option: ").strip()
        if choice == "1":
            description = input("Description (e.g. 'swiggy dinner'): ")
            amount = read_amount()
            category = choose_category(ai, description)
            add_expense(expenses, amount, category, description)
            save_expenses(expenses)
            print("Expense added.")
        elif choice == "2":
            print_expenses(expenses)
        elif choice == "3":
            print_expenses(expenses)
            raw = input("Enter ID to delete: ").strip()
            if raw.isdigit() and delete_expense(expenses, int(raw)):
                save_expenses(expenses)
                print("Expense deleted.")
            else:
                print("ID not found.")
        elif choice == "4":
            print_insights(expenses)
        elif choice == "5":
            mean, std = ExpenseCategorizer.cross_validate()
            print(f"\n5-fold cross-validated accuracy: {mean:.1%} (+/- {std:.1%})")
        elif choice == "6":
            print("Goodbye!")
            break
        else:
            print("Invalid option, try again.")


if __name__ == "__main__":
    main()
