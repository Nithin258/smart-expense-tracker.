# LinkedIn post draft (edit before posting, and add your repo link and a screenshot)

Day 20 of my Data Science internship at Codomax Digital Solutions, and I just finished my AI tools mini project. 🚀

I took the Expense Tracker I built earlier in Python and made it smarter with machine learning:

🔹 It reads what I typed ("uber to railway station") and suggests the category automatically
🔹 It flags unusually large expenses
🔹 It forecasts next month's spending from past trends

What I learned:
✅ Using AI tools like Claude to plan and write code faster, but AI code still needs testing. Mine mislabelled "biryani with friends" as Entertainment until I found it with tests and fixed it
✅ Building with scikit-learn: TF-IDF text features + Logistic Regression
✅ Being honest about results: my model scored 94% on a tiny test set, but I tuned it after seeing the results, so I treat that number as optimistic

Over the internship I went from Python basics to data analysis with Pandas and Matplotlib, and then to training my first ML models.

Code: [add your GitHub link]

Thank you @Codomax Digital Solutions for the learning experience!

#Python #MachineLearning #DataScience #AI #scikitlearn #Internship #LearningInPublic
