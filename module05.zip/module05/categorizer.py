"""AI component: a text classifier that predicts an expense category
from its description (TF-IDF character n-grams + Logistic Regression).

Character n-grams make the model tolerant to typos and unseen word forms,
e.g. "swigy" or "biryaani" still land in Food.
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline

from training_data import as_lists

CONFIDENCE_THRESHOLD = 0.45


def build_model():
    return make_pipeline(
        TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), lowercase=True),
        LogisticRegression(max_iter=1000, C=10),
    )


class ExpenseCategorizer:
    def __init__(self):
        self.model = build_model()
        self.trained = False

    def train(self, extra_texts=None, extra_labels=None):
        texts, labels = as_lists()
        if extra_texts and extra_labels:
            texts = texts + list(extra_texts)
            labels = labels + list(extra_labels)
        self.model.fit(texts, labels)
        self.trained = True
        return self

    def predict(self, description):
        """Return (category, confidence). Low confidence falls back to 'Other'."""
        if not self.trained:
            self.train()
        description = (description or "").strip()
        if not description:
            return "Other", 0.0
        probs = self.model.predict_proba([description])[0]
        best = int(probs.argmax())
        category, confidence = self.model.classes_[best], float(probs[best])
        if confidence < CONFIDENCE_THRESHOLD:
            return "Other", confidence
        return category, confidence

    def top_k(self, description, k=3):
        if not self.trained:
            self.train()
        probs = self.model.predict_proba([description])[0]
        order = probs.argsort()[::-1][:k]
        return [(self.model.classes_[i], float(probs[i])) for i in order]

    @staticmethod
    def cross_validate(folds=5):
        texts, labels = as_lists()
        scores = cross_val_score(build_model(), texts, labels, cv=folds)
        return float(scores.mean()), float(scores.std())
